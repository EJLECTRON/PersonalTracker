Iconset: Business & avatar (https://www.iconfinder.com/iconsets/business-avatar-1)
Author: Hopnguyen Mr (https://www.iconfinder.com/Mr-hopnguyen)
License: Free for commercial use ()
Download date: 2023-01-08